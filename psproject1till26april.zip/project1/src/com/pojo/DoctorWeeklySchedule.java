package com.pojo;


import java.util.HashMap;

public class DoctorWeeklySchedule {

	
	private String doctor_name;
	public HashMap<String,String> docSlotsForADay  = new HashMap<>();
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public HashMap<String, String> getDocSlotsForADay() {
		return docSlotsForADay;
	}
	public void setDocSlotsForADay(HashMap<String, String> docSlotsForADay) {
		this.docSlotsForADay = docSlotsForADay;
	}
	
}

