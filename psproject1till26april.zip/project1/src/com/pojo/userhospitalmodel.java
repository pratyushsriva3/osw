package com.pojo;



public class userhospitalmodel {

	
	private int tableid;
	private String UserID;
	private String hosid;
	public int getTableid() {
		return tableid;
	}
	public void setTableid(int tableid) {
		this.tableid = tableid;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getHosid() {
		return hosid;
	}
	public void setHosid(String hosid) {
		this.hosid = hosid;
	}
	
	
}
