package com.pojo;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class DoctorSchedule {
private String docname;
public TreeMap<String,String> docSlot  = new TreeMap<>();
public String getDocname() {
	return docname;
}
public TreeMap<String, String> getDocSlot() {
	return docSlot;
}
public void setDocSlot(TreeMap<String, String> docSlot) {
	this.docSlot = docSlot;
}
public void setDocname(String docname) {
	this.docname = docname;
}



}
